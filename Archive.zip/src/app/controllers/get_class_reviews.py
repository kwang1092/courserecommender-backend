from . import *
from flask import jsonify, request

class GetClassReviewsController(AppDevController):

  def get_path(self):
    return '/class_reviews/<class_name>/'

  def get_methods(self):
    return ['GET']

  def content(self, **kwargs):
    class_name = request.view_args['class_name']
    reviews = class_dao.get_class_reviews(class_name)
    return jsonify(reviews)
