from . import *
from flask import jsonify, request


class GetProfReviewsController(AppDevController):

  def get_path(self):
    return '/prof_reviews/<prof_name>/'

  def get_methods(self):
    return ['GET']

  def content(self, **kwargs):
    prof_name = request.view_args['prof_name']
    reviews = prof_dao.get_prof_reviews(prof_name)
    return jsonify(reviews)
