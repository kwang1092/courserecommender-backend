Course recommender backend
We created the of the end points to add and retrieve reviews for classes and professors.
